package com.john_inc.remotecontrol;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final int SIXTY_SECONDS = 60;
    private static final int SERVER_PORT = 11000;
    private static final int TIMEOUT = 5000;
    private static final int MAX_VOLUME = 65535;
    private static final String CONNECTION_ERROR = "Connection error!";
    private ArrayList<ControllableDevice> controllableDevices = new ArrayList<>();
    private ArrayList<String> controllableDeviceNames = new ArrayList<>();
    private ControllableDevice selectedControllableDevice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupVolumeBar();
        setupSpinner();
        read();
    }

    @Override
    protected void onStart() {
        super.onStart();
        findServer();
    }

    @Override
    protected void onStop() {
        super.onStop();
        write();
    }

    public void start(View view) {
        final EditText macAddress = (EditText) findViewById(R.id.editText_mac);
        //final EditText ipAddress = new EditText();

        new Thread(new Runnable() {
            @Override
            public void run() {
                String macStr;
                toggleProgressBar();
                try {
                    macStr = MagicPacket.cleanMac(macAddress.getText().toString());
                    System.out.println("Sending to: " + macStr);
                    String s = MagicPacket.send(macStr, selectedControllableDevice.getIpAddress().getHostAddress());
                    System.out.println(s);
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                } catch (Exception e) {
                    System.out.println("Failed to send Wake-on-LAN packet:" + e.getMessage());
                }
                toggleProgressBar();
            }
        }).start();
    }

    public void shutdown(View view) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                toggleProgressBar();
                try {
                    EditText editTextMinutes = (EditText) findViewById(R.id.editText_minutes);

                    int seconds;
                    String minutes = editTextMinutes.getText().toString();

                    if (minutes.isEmpty()) {
                        seconds = SIXTY_SECONDS;
                    } else {
                        seconds = Integer.parseInt(minutes) * SIXTY_SECONDS;
                    }

                    Message shutdownMessage = new Message(Command.SHUTDOWN_COMMAND, new String[]{Integer.toString(seconds)});

                    String shutdownMessageAsString = new Gson().toJson(shutdownMessage) + Message.MESSAGE_TERMINATOR;
                    sendMessage(shutdownMessageAsString);
                } catch (Exception e) {
                    setErrorMessage(e.getMessage());
                }
                toggleProgressBar();
            }
        }).start();
    }

    public void cancelShutdown(View v) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                toggleProgressBar();
                try {
                    Message cancelShutdown = new Message(Command.CANCEL_SHUTDOWN, new String[]{""});

                    String s = new Gson().toJson(cancelShutdown) + Message.MESSAGE_TERMINATOR;
                    sendMessage(s);
                } catch (Exception e) {
                    setErrorMessage(e.getMessage());
                }
                toggleProgressBar();
            }
        }).start();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String name = parent.getItemAtPosition(position).toString();
        updateSelectedControllableDevice(name);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        selectedControllableDevice = null;
    }

    // Read the IP and MAC from the preference file.
    private void read() {
        EditText mac = (EditText) findViewById(R.id.editText_mac);

        SharedPreferences sharedPreferences = getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE
        );

        String defaultMAC = getString(R.string.device_MAC_default);
        mac.setText(sharedPreferences.getString(getString(R.string.device_MAC), defaultMAC));
    }

    // Write the data to the preference file.
    private void write() {
        EditText mac = (EditText) findViewById(R.id.editText_mac);

        SharedPreferences sharedPref = getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE
        );
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(getString(R.string.device_MAC), mac.getText().toString());
        editor.apply();
    }

    private void setupVolumeBar() {
        SeekBar seekBar = (SeekBar) findViewById(R.id.seekBar_volume);

        seekBar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(final SeekBar seekBar) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                toggleProgressBar();
                                try {
                                    int volume = (seekBar.getProgress() * MAX_VOLUME) / 100;
                                    Message m = new Message(Command.VOLUME_CHANGE_COMMAND, new String[]{Integer.toString(volume)});
                                    String s = new Gson().toJson(m) + Message.MESSAGE_TERMINATOR;
                                    sendMessage(s);
                                } catch (Exception e) {
                                    setErrorMessage(e.getMessage());
                                }
                                toggleProgressBar();
                            }
                        }).start();
                        System.out.println("stop tracking, progress = " + seekBar.getProgress());
                    }
                }
        );
    }

    private void setupSpinner() {
        Spinner spinner = (Spinner) findViewById(R.id.controllable_devices_spinner);
        spinner.setOnItemSelectedListener(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, controllableDeviceNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    private void toggleProgressBar() {
        final ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);

        progressBar.post(new Runnable() {
            @Override
            public void run() {
                if (progressBar.isShown()) {
                    progressBar.setVisibility(View.INVISIBLE);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private void sendMessage(final String message) {
        toggleProgressBar();
        try {
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress(selectedControllableDevice.getIpAddress(), SERVER_PORT), TIMEOUT);

            if (socket.isConnected()) {
                PrintWriter out = new PrintWriter(new BufferedWriter(
                        new OutputStreamWriter(socket.getOutputStream())
                ), true);
                out.print(message);
                out.flush();
                out.close();
                setErrorMessage("");
            } else
                setErrorMessage(CONNECTION_ERROR);
            socket.close();
        } catch (Exception e) {
            setErrorMessage(e.getMessage());
        }
        toggleProgressBar();
    }

    private void findServer() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    DatagramSocket socket = new DatagramSocket();
                    socket.setBroadcast(true);
                    byte[] message = "WhoAreYou".getBytes();
                    try {
                        DatagramPacket packet = new DatagramPacket(message, message.length, InetAddress.getByName("255.255.255.255"), SERVER_PORT);
                        socket.send(packet);

                    } catch (Exception e) {
                        setErrorMessage(e.getMessage());
                    }
                    socket.setSoTimeout(5000);
                    DatagramPacket receivedPacket;
                    byte[] receivingBuffer = new byte[256];
                    boolean receivingResponses = true;
                    while (receivingResponses) {
                        try {
                            receivedPacket = new DatagramPacket(receivingBuffer, receivingBuffer.length);
                            socket.receive(receivedPacket);
                            String serverResponse = new String(receivedPacket.getData()).trim();
                            if (serverResponse.length() == 0) {
                                receivingResponses = false;
                            } else {
                                if (!controllableDeviceExists(receivedPacket.getAddress().getHostAddress())) {
                                    controllableDevices.add(new ControllableDevice(serverResponse, receivedPacket.getAddress()));
                                }
                                loadSpinnerData();
                            }
                        } catch (SocketTimeoutException e) {
                            if (controllableDevices.isEmpty()) {
                                setErrorMessage(e.getMessage());
                            } else {
                                receivingResponses = false;
                            }
                        } catch (Exception e) {
                            setErrorMessage(e.getMessage());
                        }
                    }
                    socket.close();
                } catch (Exception e) {
                    setErrorMessage(e.getMessage());
                }
            }
        }).start();
    }

    private synchronized void loadSpinnerData() {
        updateControllableDeviceNames();
        runOnUiThread(new Runnable() {
            @Override
            public synchronized void run() {
                Spinner spinner = (Spinner) findViewById(R.id.controllable_devices_spinner);
                ((BaseAdapter) spinner.getAdapter()).notifyDataSetChanged();
            }
        });
    }

    private void updateControllableDeviceNames() {
        controllableDeviceNames.clear();
        for (ControllableDevice controllableDevice : controllableDevices) {
            controllableDeviceNames.add(controllableDevice.getName());
        }
    }

    private void setErrorMessage(final String message) {
        final TextView textView = (TextView) findViewById(R.id.textView_errors);
        textView.post(new Runnable() {
            @Override
            public void run() {
                textView.setText(message);
            }
        });
    }

    private void updateSelectedControllableDevice(String name) {
        selectedControllableDevice = null;
        for (ControllableDevice controllableDevice : controllableDevices) {
            if (name.equals(controllableDevice.getName())) {
                selectedControllableDevice = controllableDevice;
            }
        }
    }

    private boolean controllableDeviceExists(String ipAddress) {
        for (ControllableDevice controllableDevice : controllableDevices) {
            if (ipAddress.equals(controllableDevice.getIpAddress().getHostAddress())) {
                return true;
            }
        }

        return false;
    }
}

