package com.john_inc.remotecontrol;

import com.google.gson.annotations.SerializedName;

/**
 * Created by John on 11/30/2017.
 */

public class Message {
    public static final transient String MESSAGE_TERMINATOR = "\\";
    @SerializedName("Command") private Command command;

    public Message(String commandName, String[] commandParameters) {
        command = new Command(commandName, commandParameters);
    }
}
