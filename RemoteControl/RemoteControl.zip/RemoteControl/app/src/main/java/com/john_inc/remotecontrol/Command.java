package com.john_inc.remotecontrol;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by John on 11/30/2017.
 */

class Command {
    public static final transient String SHUTDOWN_COMMAND = "Shutdown";
    public static final transient String VOLUME_CHANGE_COMMAND = "VolumeChange";
    public static final transient String CANCEL_SHUTDOWN = "CancelShutdown";

    private String commandName;
    private String[] commandParameters;

    public Command(String commandName, String[] commandParameters){
        this.commandName = commandName;
        this.commandParameters = commandParameters;
    }
}
